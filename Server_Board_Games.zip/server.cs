if (!isObject($GameList)) {
	$GameList = new SimSet() {
		gameTypes = 1;
		type0 = "Connect4";
	};
}

exec("./buildload.cs");
exec("./connect4.cs");
exec("./uttt.cs");
exec("./othello.cs");

exec("./chessItems.cs");

$uttt = "Add-ons/Server_Board_Games/uttt.cs";
$connect4 = "Add-ons/Server_Board_Games/connect4.cs";
$othello = "Add-ons/Server_Board_Games/othello.cs";
$boardgame = "Add-ons/Server_Board_Games/server.cs";


datablock fxDTSBrickData(brickConnect4Data){
	brickFile = "./bricks/connect4.blb";
	uiName = "Connect4 Brick";

	category = "Special";
	subCategory = "Board Games";
	iconName = "";
};

datablock fxDTSBrickData(brickChessboard6x6Data){
	brickFile = "./bricks/Chessboard6x6.blb";
	uiName = "Chessboard 6x6";

	category = "Special";
	subCategory = "Board Games";
	iconName = "";	
};

datablock fxDTSBrickData(brickOthelloWhite6x6Data : brickChessboard6x6Data) {
	brickFile = "./bricks/othelloWhite.blb";
	uiName = "Othello - White";
};

datablock fxDTSBrickData(brickOthelloBlack6x6Data : brickChessboard6x6Data) {
	brickFile = "./bricks/othelloBlack.blb";
	uiName = "Othello - Black";
};

datablock fxDTSBrickData(brickOthelloEmpty6x6Data : brickChessboard6x6Data) {
	brickFile = "./bricks/othelloEmpty.blb";
	uiName = "Othello - Empty";
};


package BoardGame {
	function GameConnection::createPlayer(%this, %pos) {
		if (%this.inBoardGame) {
			%pos = %this.boardGameSpawn;
			if (%pos $= "") {
				talk("Error: Player in board game does not have spawn assigned");
			}
		}
		return parent::createPlayer(%this, %pos);
	}

	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		//talk(%obj SPC %col SPC %a SPC %b SPC %c SPC %d SPC %e SPC %f);
		//lets you pick up multiple proptools if disappear on use is enabled
		if(%col.getDatablock().cannotPickup)
		{
			return;
		}
		return parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}

	function Player::activateStuff(%player) {
		%client = %player.client;
		if (%client.inBoardGame) {
	        %start = getWords(%player.getEyeTransform(), 0, 2);
	        %end = vectorAdd(vectorScale(%player.getEyeVector(), 35), %start);
	        %masks = $TypeMasks::FxBrickObjectType | $TypeMasks::TerrainObjectType;
	        %ray = containerRaycast(%start, %end, %masks, %player);
	        %hit = getWord(%ray, 0);
	        if (%hit.getClassName() $= "FxDTSBrick" && strLen(stripChars(%hit.getName(), "_")) > 0) {
	        	if (%hit.getGroup() != %client.boardGame.brickGroup) {
	        		return parent::activateStuff(%player);
	        	}
	        	%col = getSubStr(%hit.getName(), 1, strLen(%hit.getName()));
	        	%client.boardGame.takeTurn(%col, %client);
	        }
	    }
	    return parent::activateStuff(%player);
	}

	function GameConnection::onDrop(%client, %param) {
		if (isObject(%client.boardGame)) {
			%enemyTeam = (%client.boardGame.player0 == %client ? 1 : 0);
			%client.boardGame.endGame(%enemyTeam);
			messageAll('', "\c7" @ %client.name @ " pussied out of their game!");
		}
		return parent::onDrop(%client, %param);
	}
};
activatePackage(BoardGame);

$nextBrickgroup = 800813;

function getNextGameBrickgroupID() {
	if ($nextBrickgroup == 888888) {
		$nextBrickgroup = 800813;
	}
	$nextBrickgroup++;
	return $nextBrickgroup - 1;
}

function chainKillBrickGroup(%brickGroup, %i) {
	if (%i < 0) {
        %brickGroup.schedule(1000, delete);
		return;
	}
	%brickGroup.getObject(%i).killBrick();
	schedule(1, 0, chainKillBrickGroup, %brickGroup, %i--);
}


//////////////
//servercmds//
//////////////

$listOfGames = "Connect4 UTTT Othello";
function serverCmdChallenge(%cl, %name, %boardgame) {
	%challenged = fcn(%name);
	if (%boardgame $= "" || (%pos = strPos(strlwr($listOfGames), strlwr(%boardgame))) < 0) {
		messageClient(%cl, '', "<font:Arial Bold:18>\c5Usage\c6: /challenge [name] [" @ strReplace($listOfGames, " ", "/") @ "]");
		return;
	} else if (isObject(%challenged.currChallengeTo) || isObject(%challenged.currChallengeBy) || isObject(%challenged.boardgame)) {
		messageClient(%cl, '', "<font:Arial Bold:18>\c3" @ %challenged.name @ "\c5 is busy right now.");
		return;
	} else if (isObject(%cl.currChallengeTo)) {
		messageClient(%cl, '', "<font:Arial Bold:18>\c5You can only challenge one player at a time!");
		return;
	} else if (isObject(%cl.currChallengeBy)) {
		messageClient(%cl, '', "<font:Arial Bold:18>\c5You are currently being challenged - /deny or /accept them before challenging others!");
		return;
	} else if (isObject(%cl.boardgame)) {
		messageClient(%cl, '', "<font:Arial Bold:18>\c5You can't challenge someone while in a board game!");
		return;
	} else if (%cl == %challenged) {
		messageClient(%cl, '', "<font:Arial Bold:18>\c5You can't challenge yourself!");
		return;
	}

    challengeToGame(%challenged, %cl, %boardGame);
    messageClient(%cl, '', "<font:Arial Bold:18>\c5----------------");
    messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c5You have challenged \c3" @ %challenged.name @ "\c5 to a game of \c3" @ %boardGame);
    messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c5Use \c3/cancel\c5 to cancel your challenge");
    messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c7This challenge will time out in 20 seconds");
    messageClient(%cl, '', "<font:Arial Bold:18>\c5----------------");
    %cl.currChallengeTo = %challenged;
    %cl.currGameChallenge = %boardgame;
}

function challengeToGame(%cl, %challenger, %boardgame) {
	messageClient(%cl, '', "<font:Arial Bold:18>\c5----------------");
    messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c5You have been challenged by \c3" @ %challenger.name @ "\c5 to a game of \c3" @ %boardGame);
    messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c5You can \c3/accept\c5 or \c3/decline\c5 this challenge.");
    messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c7This challenge will time out in 20 seconds");
    messageClient(%cl, '', "<font:Arial Bold:18>\c5----------------");
    %cl.currChallengeBy = %challenger;
    %cl.currGameChallenge = %boardgame;
    %cl.currChallengedSchedule = schedule(20000, 0, challengeExpired, %challenger, %cl, %boardgame);
}

function serverCmdAccept(%cl) {
	if (!isObject(%cl.currChallengeBy)) {
		return;
	}
	eval("start" @ %cl.currGameChallenge @ "Game(" @ %cl @ ", " @ %cl.currChallengeBy @ ");");
	%challenger = %cl.currChallengeBy;
	%challenged = %cl;
	messageAll('', "<font:Arial Bold:18>\c3" @ %challenger.name @ "\c5 and \c3" @ %challenged.name @ "\c5 have started a game of \c3" @ %challenger.currGameChallenge @ "\c5!");

	%challenger.currChallengeTo = "";
	%challenged.currChallengeBy = "";
	%challenger.currGameChallenge = "";
	%challenged.currGameChallenge = "";
	cancel(%cl.currChallengedSchedule);	
}

function serverCmdDecline(%cl) {
	if (!isObject(%cl.currChallengeBy)) {
		return;
	}
	messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c5You have declined \c3" @ %cl.currChallengeBy.name @ "\c5's challenge to a game of \c6" @ %cl.currGameChallenge @ "\c5.");
	messageClient(%cl.currChallengeBy, 'MsgUploadEnd', "<font:Arial Bold:18>\c3" @ %cl.name @ "\c5 has declined the challenge.");
	challengeExpired(%cl.currChallengeBy, %cl, %cl.currGameChallenge);
}

function serverCmdCancel(%cl) {
	if (!isObject(%cl.currChallengeTo)) {
		return;
	}
	messageClient(%cl, 'MsgUploadEnd', "<font:Arial Bold:18>\c5You have canceled your challenge to \c3" @ %cl.currChallengeTo.name @ "\c5.");
	messageClient(%cl.currChallengeTo, 'MsgUploadEnd', "<font:Arial Bold:18>\c4" @ %cl.name @ "\c5 has canceled their challenge.");
	challengeExpired(%cl, %cl.currChallengeTo, %cl.currGameChallenge);
}

function challengeExpired(%challenger, %challenged, %game) {
	messageClient(%challenger, 'MsgUploadEnd', "<font:Arial Bold:18>\c5The " @ %game @ " game has expired.");
	messageClient(%challenged, 'MsgUploadEnd', "<font:Arial Bold:18>\c5The " @ %game @ " game has expired.");

	%challenger.currChallengeTo = "";
	%challenged.currChallengeBy = "";
	%challenger.currGameChallenge = "";
	%challenged.currGameChallenge = "";
	cancel(%challenged.currChallengedSchedule);	
}

function fullShutdown() {
	shutdown();
	export("$pre*", "config/server/prefs.cs");
	schedule(1000, 0, quit);
}